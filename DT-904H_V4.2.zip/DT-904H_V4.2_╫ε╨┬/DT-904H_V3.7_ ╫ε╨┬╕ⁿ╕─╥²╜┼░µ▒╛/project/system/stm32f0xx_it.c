
/**
  ******************************************************************************
  * @file    GPIO/GPIO_IOToggle/stm32f0xx_it.c 
  * @author  MCD Application Team
  * @version V1.4.0
  * @date    24-July-2014
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and 
  *          peripherals interrupt service routine.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2014 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software 
  * distributed under the License is distributed on an "AS IS" BASIS, 
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm32f0xx_it.h"
#include "main.h"

/** @addtogroup STM32F0xx_StdPeriph_Examples
  * @{
  */

/** @addtogroup GPIO_IOToggle
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
uint32_t TimeCount;
uint8_t TimeFlag;

uint32_t T_Value1;
uint32_t T_Value2;
uint32_t T_Value3;

uint32_t IC4Value[3];
uint32_t MiddleValue[3];

uint16_t CaptureNum;
uint32_t CaptureTime;   // ��¼��ֵʱ�� //

uint16_t SignNum1; 
uint16_t SignNum2;
uint16_t SignNum3; 

uint16_t Sign2Num1; 
uint16_t Sign2Num2;
uint16_t Sign2Num3; 

bool flag1;
bool flag2;
bool flag3; 

bool SignFlag1;
bool SignFlag2;
bool SignFlag3;
bool SignFlag4;

bool Led_Flag;
bool Phase_Flag;    //�����־//

bool PhaseLine_Flag;

uint8_t  Led_Num;
uint8_t  TimeNum;
uint8_t  Phase_Start;  //��¼����ǰ״̬//

extern uint16_t TimeCount3s;//ʱ�����
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
void SensorOut_Dealwith(void);
/******************************************************************************/
/*            Cortex-M0 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
  * @brief  This function handles NMI exception.
  * @param  None
  * @retval None
  */
void NMI_Handler(void)
{
}

/**
  * @brief  This function handles Hard Fault exception.
  * @param  None
  * @retval None
  */
void HardFault_Handler(void)
{
  /* Go to infinite loop when Hard Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles SVCall exception.
  * @param  None
  * @retval None
  */
void SVC_Handler(void)
{
}

/**
  * @brief  This function handles PendSVC exception.
  * @param  None
  * @retval None
  */
void PendSV_Handler(void)
{
}

/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */
void SysTick_Handler(void)
{
}

/******************************************************************************/
/*                 STM32F0xx Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f0xx.s).                                               */
/******************************************************************************/

/**
  * @brief  This function handles PPP interrupt request.
  * @param  None
  * @retval None
  */
/*void PPP_IRQHandler(void)
{
}*/
/* ��ʱ��14�ж� 500US*/
void TIM14_IRQHandler(void)
{
	 if (TIM_GetITStatus(TIM14, TIM_IT_Update) != RESET)
    {
		SensorOut_Dealwith();
		TIM_ClearITPendingBit(TIM14, TIM_IT_Update);
    }
}
/* ��ʱ��3�ж� 100US*/
void TIM3_IRQHandler(void)
{
	 if (TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET)
    {   
	    CaptureTime ++;
		TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
    }
}
void EXTI0_1_IRQHandler(void)    
{
     if(EXTI_GetITStatus(EXTI_Line0) != RESET)    // ���������ж�
     {	 
	      /* Clear the EXTI line 1 pending bit */
           EXTI_ClearITPendingBit(EXTI_Line0);
	 }  
}
void EXTI4_15_IRQHandler(void)      //�����жϻ���˯��
{
	 if(EXTI_GetITStatus(EXTI_Line4) != RESET)   
     {	
      // /* Clear the EXTI line 4 pending bit */
       EXTI_ClearITPendingBit(EXTI_Line4);
     }   
     if(EXTI_GetITStatus(EXTI_Line6) != RESET)    // PA6 �����ź����������ж�
     {    
	       CaptureTime =0;
	       TIM3->CNT &= 0x0000; 
           TIM_Cmd(TIM3, ENABLE);    
           /* Clear the EXTI line 4 pending bit */
           EXTI_ClearITPendingBit(EXTI_Line6);
     }	  
	 if(EXTI_GetITStatus(EXTI_Line9) != RESET)    // ���������ж�
     {	 
	             // if(!SignFlag4)
			     // {
	               TIM_Cmd(TIM17, ENABLE);     //��ʱ��17 ʹ��
                   TIM_CtrlPWMOutputs(TIM17, ENABLE); 
			       // }                   
					 if(Led_Flag!=1)
		             {
	                  if(TimeFlag==0)
					 {					 
                        TIM_Cmd(TIM3, DISABLE);    
                        TIM3->CNT &= 0x0000; 						   
		                IC4Value[0]=CaptureTime;	
					 }		
					 else if(TimeFlag==1)
					 {  
                        TIM_Cmd(TIM3, DISABLE);    
                        TIM3->CNT &= 0x0000; 						   
		                IC4Value[1]=CaptureTime;	
					 }
				     else if(TimeFlag==2)
					 {		 
                        TIM_Cmd(TIM3, DISABLE);    
                        TIM3->CNT &= 0x0000; 						   
		                IC4Value[2]=CaptureTime;	            
				     }		 
					 else 
					 {;}
					 }
	     // /* Clear the EXTI line 1 pending bit */
           EXTI_ClearITPendingBit(EXTI_Line9);
	 } 	 
}
void SensorOut_Dealwith(void)     
{	
              /********  ��¼������λ֮���ʱ��  ********/	
		       switch (TimeFlag)
              {
            	case 0:{  	 
					 _74VHC4052_A_Low;       //74HCV4052  A ��, B ��   T
                     _74VHC4052_B_Low;	
					 _TC7S66FU_CONT_Low;    // ����TC7S66FUʹ��	 		
					 if(TimeCount==120)      //60MS
					 {			
                       TimeFlag = 1;  
                       TimeCount = 0;	 					   
					 }
				     else 					 
					 {  
				            TimeCount++;	

                            if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9)==Bit_RESET)
					        {
					  	    SignNum1++;
							Sign2Num1=0; 
						    if((SignNum1>=100)&&(SignNum1<=120))    //20ms	~ 30mS
						    {	  
                            SignFlag1=0;	
                            SignNum1 =0;							
						    }
					        }
                            else 
					        { 
						      Sign2Num1++;
							  SignNum1=0;  
                            if((Sign2Num1>=16) && (Sign2Num1<=20))   //8ms	~ 10MS
							{
							   SignFlag1=1;	
							}								
					        }	

					 }								         
				    }		 
            		break;									
            	case 1:{
				     _74VHC4052_A_Hig;        //74HCV4052  A ��, B ��   S
                     _74VHC4052_B_Low;
                     _TC7S66FU_CONT_Low;    // ����TC7S66FUʹ��
					 if(TimeCount==120)      //60MS
					 {
					    TimeFlag=2;
					    TimeCount=0;        
					 }				 
				     else 
					 {  
				            TimeCount++;	
						
						    if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9)==Bit_RESET)
					        {
					  	     SignNum2++;
						     Sign2Num2=0; 
						    if((SignNum2>=100)&&(SignNum2<=120))    //50ms	~ 60mS
						    {	  
                             SignFlag2=0;	
                             SignNum2=0;							
						    }
					        }
                            else 
					        { 
					         Sign2Num2++;
							 SignNum2=0;
							
                             if((Sign2Num2>=16) && (Sign2Num2<=20))   //8ms	~ 10MS
							{
							   SignFlag2=1;	
							}								
					        } 
	
					 }
					} 
            		break;		
				case 2:{
                     _74VHC4052_A_Low;         //74HCV4052  A ��, B ��  R
                     _74VHC4052_B_Hig; 			 					 
					 _TC7S66FU_CONT_Low;    // ����TC7S66FUʹ��				 
                     if(TimeCount==120)      //60MS
					 {
				       TimeFlag = 3;  
					   TimeCount = 0;			   
					 }
                      else             
					 {  
				             TimeCount++;
             
					   		 if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9)==Bit_RESET)
					         {
					  	      SignNum3++;
						 	  Sign2Num3=0;
						     if((SignNum3>=100)&&(SignNum3<=120))   //50ms	~ 60mS
						     {	  
                              SignFlag3=0;	
                              SignNum3=0;							
						     }
					         }
                             else 
					         { 
							  Sign2Num3++;
							  SignNum3=0;	
                             if((Sign2Num3>=16) && (Sign2Num3<=20))   //8ms	~ 10MS
							 { 
							   SignFlag3=1;	
							 }									
					         }		   

					 }			
					  
					}
            		break;	
				
					
            	default:
				{	
				
		        if((!SignFlag1)&(!SignFlag2)&(SignFlag3!=0))     
				{Led_Num = 0x01; 
			     TIM_Cmd(TIM6, DISABLE); 
				 TimeCount3s=0;
			     PhaseLine_Flag=1;			
				} 
		        else if((!SignFlag1)&(SignFlag2!=0)&(!SignFlag3))
				{Led_Num = 0x02;
			     TIM_Cmd(TIM6, DISABLE);
                 TimeCount3s=0;
                 PhaseLine_Flag=1;					
				 }	 
		        else if((SignFlag1!=0)&(!SignFlag2)&(!SignFlag3))
				{Led_Num = 0x03; 
			     TIM_Cmd(TIM6, DISABLE);
                 TimeCount3s=0;		
                 PhaseLine_Flag=1;					
				 }	 	 
		        else if((!SignFlag1)&(SignFlag2!=0)&(SignFlag3!=0))
				{Led_Num = 0x04;
                 TIM_Cmd(TIM6, DISABLE); 
				 TimeCount3s=0;
				 PhaseLine_Flag=1;	
				 }
		        else if((SignFlag1!=0)&(SignFlag2!=0)&(!SignFlag3))
				{Led_Num = 0x05; 
			     TIM_Cmd(TIM6, DISABLE);
                 TimeCount3s=0;		
                 PhaseLine_Flag=1;					
				 }
                else if((SignFlag1!=0)&(!SignFlag2)&(SignFlag3!=0))
				{Led_Num = 0x06;
                 TIM_Cmd(TIM6, DISABLE);
                 TimeCount3s=0;		
                 PhaseLine_Flag=1;					
				 }
		        else if((SignFlag1!=0)&(SignFlag2!=0)&(SignFlag3!=0))
				{Led_Num = 0x07; 
			     TIM_Cmd(TIM6, DISABLE); 
				 TimeCount3s=0;
			     PhaseLine_Flag=1;
				 } 
                else					
				{Led_Num = 0x00;
			     TIM_Cmd(TIM6, ENABLE);
                 PhaseLine_Flag=0;					
			    } 
		        switch(Led_Num)
		        {
		        case 0x00:{ GPIO_SetBits(GPIOB, GPIO_Pin_4);           //ȫ��
	                        GPIO_SetBits(GPIOB, GPIO_Pin_5);			 
		                    GPIO_SetBits(GPIOB, GPIO_Pin_8); }break; 
		        case 0x01:{ GPIO_ResetBits(GPIOB, GPIO_Pin_8);	       //��
		                    GPIO_SetBits(GPIOB, GPIO_Pin_4);          
	                        GPIO_SetBits(GPIOB, GPIO_Pin_5); }break;
		        case 0x02:{ GPIO_ResetBits(GPIOB, GPIO_Pin_4);         //��
                            GPIO_SetBits(GPIOB, GPIO_Pin_8);
	                        GPIO_SetBits(GPIOB, GPIO_Pin_5); }break;
		        case 0x03:{ GPIO_ResetBits(GPIOB, GPIO_Pin_5);         //��
                            GPIO_SetBits(GPIOB, GPIO_Pin_8);
	                        GPIO_SetBits(GPIOB, GPIO_Pin_4); }break;
		        case 0x04:{ GPIO_ResetBits(GPIOB, GPIO_Pin_8);		   //���
		                    GPIO_ResetBits(GPIOB, GPIO_Pin_4);
		                    GPIO_SetBits(GPIOB, GPIO_Pin_5); }break;	 
                case 0x05:{ GPIO_ResetBits(GPIOB, GPIO_Pin_4);		   //����
		                    GPIO_ResetBits(GPIOB, GPIO_Pin_5);
		                    GPIO_SetBits(GPIOB, GPIO_Pin_8);} break;	
                case 0x06:{ GPIO_ResetBits(GPIOB, GPIO_Pin_8);		   //����
		                    GPIO_ResetBits(GPIOB, GPIO_Pin_5);
		                    GPIO_SetBits(GPIOB, GPIO_Pin_4);} break;					 
                case 0x07:{ GPIO_ResetBits(GPIOB, GPIO_Pin_8);         //�����
                            GPIO_ResetBits(GPIOB, GPIO_Pin_4);		  
		                    GPIO_ResetBits(GPIOB, GPIO_Pin_5);}break;	
		        default:{;}break;
		        }				
					 
					
					   if(TimeNum<10)
					   {
						 TimeNum ++;
						 MiddleValue[0] = MiddleValue[0] + IC4Value[0]; //C    0X~0Y ��ȡ3�μ���ֵ
                         MiddleValue[1] = MiddleValue[1] + IC4Value[1]; //B    1X~1Y
                         MiddleValue[2] = MiddleValue[2] + IC4Value[2]; //A    2X~2Y
					   }						   
					   if(TimeNum>=10)
					   {
					     T_Value1 = MiddleValue[0]/10; //C    0X~0Y ��ȡ3�μ���ֵ
                         T_Value2 = MiddleValue[1]/10; //B    1X~1Y
                         T_Value3 = MiddleValue[2]/10; //A    2X~2Y

                         IC4Value[0] =0; //C    0X~0Y ��ȡ3�μ���ֵ
                         IC4Value[1] =0; //B    1X~1Y
                         IC4Value[2] =0; //A    2X~2Y
						 
						 MiddleValue[0]=0; //C    0X~0Y ��ȡ3�μ���ֵ
                         MiddleValue[1]=0; //B    1X~1Y
                         MiddleValue[2]=0; //A    2X~2Y

                         TimeNum = 0;  
        
		               	if((SignFlag1!=0)&(SignFlag2!=0)&(SignFlag3!=0))   //������ǯ���ϲ���Ч// 
	                    {    
						     if((T_Value1>T_Value2)&&(T_Value2>T_Value3))  
							 {
							     LED2_OPEN;	       //����
	                             LED3_CLOSE;  
                                 Phase_Start=0x01;	
							 }
							 else
							 {
								 LED3_OPEN;         //����	
	                             LED2_CLOSE;										 
								 Phase_Start=0x02;	 
							 }						 
			                     Phase_Flag=1;     //ǯ��״̬��־//
					    }
		                else 
					    {
					             LED3_CLOSE;               
	                             LED2_CLOSE;		
							     Phase_Start=0x00;	
								 
								 T_Value1 = 0; //A    0X~0Y ��ȡ3�μ���ֵ
                                 T_Value2 = 0; //B    1X~1Y
                                 T_Value3 = 0; //C    2X~2Y	
					
								 Phase_Flag=0;     //ǯ��״̬��־////
					    }	
			        } 
					
                   	TimeFlag = 0;  
					TimeCount = 0;					   
					CaptureNum = 0;		     //���㲶�񵽵�ʱ��
			     
					SignNum3 =0;
                    SignNum2 =0;
                    SignNum1 =0;  
					
					Sign2Num3 =0;
                    Sign2Num2 =0;
                    Sign2Num1 =0;  
					
					SignFlag1=0;	
					SignFlag2=0;	
					SignFlag3=0;	
						
                	TIM_Cmd(TIM17, DISABLE);     //��ʱ��17 ʹ��
                    TIM_CtrlPWMOutputs(TIM17, DISABLE);   			
				    TIM17->CNT &= 0x0000; 					
				}
            	  break;
				  
             }
}
/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
