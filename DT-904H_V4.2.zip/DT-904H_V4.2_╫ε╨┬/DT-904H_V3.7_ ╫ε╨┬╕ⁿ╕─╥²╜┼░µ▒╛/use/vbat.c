#include "vbat.h"
__IO float Save_adc;
uint8_t adc_done = 0x00;
uint16_t adc_GetNum;
void Vbat_Init(void)
{
  ADC_InitTypeDef     ADC_InitStruct;
  GPIO_InitTypeDef    GPIO_InitStruct;
 
  /* ADC1 DeInit */  
  ADC_DeInit(ADC1);
  /* Enable  GPIOA clock */
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);	
  /* ADC1 eriph clock enable */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
    /* SYSCFG clock enable */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);
  
  /* Configure A.01  as analog input */
  GPIO_InitStruct.GPIO_Pin = GPIO_Pin_0;
  GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AN;
  GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL ;
  GPIO_Init(GPIOA, &GPIO_InitStruct);
  /* Initialize ADC structure */
  ADC_StructInit(&ADC_InitStruct);
  /* Configure the ADC1 in continous mode withe a resolutuion equal to 12 bits  */
  ADC_InitStruct.ADC_Resolution = ADC_Resolution_12b; //ADC数据12位模式
  ADC_InitStruct.ADC_ContinuousConvMode = ENABLE;     //ADC使能连续转换模式
  ADC_InitStruct.ADC_ExternalTrigConvEdge = ADC_ExternalTrigConvEdge_None;   //禁止外部触发ADC转换
  ADC_InitStruct.ADC_DataAlign = ADC_DataAlign_Right;            //ADC数据右对齐模式
  ADC_InitStruct.ADC_ScanDirection = ADC_ScanDirection_Upward;   //ADC向上扫描模式
  ADC_Init(ADC1, &ADC_InitStruct); 
   
  ADC_ChannelConfig(ADC1, ADC_Channel_0 , ADC_SampleTime_55_5Cycles);
  /* ADC Calibration */
  ADC_GetCalibrationFactor(ADC1);
  /* Enable the ADC peripheral */
  ADC_Cmd(ADC1, ENABLE);     
  /* Wait the ADCEN falg */
  while(!ADC_GetFlagStatus(ADC1, ADC_FLAG_ADEN)); 
  	/* ADC1 regular Software Start Conv */ 
  ADC_StartOfConversion(ADC1);  
}
/*KalmanFilter*/
uint32_t KalmanFilter(int32_t ResrcData)
{
    /*-------------------------------------------------------------------------------------------------------------*/
    /*
            Q:过程噪声，Q增大，动态响应变快，收敛稳定性变坏
            R:测量噪声，R增大，动态响应变慢，收敛稳定性变好
    */
    /*-------------------------------------------------------------------------------------------------------------*/
    static int32_t R = (int32_t)(128*1024);
    static int32_t Q = (int32_t)4;
    static uint32_t Counter1 = 0;
    static uint32_t Counter2 = 0;
    static int32_t x_last = 0;
        static int32_t p_last;   // 应赋初始估计值
    int32_t x_mid;
    int32_t x_now;
    int32_t p_mid ;
    int32_t p_now;
 
    ResrcData *= 1024;
    x_now = ResrcData - x_last;
    if(x_now < 0)
    {
        x_now *= -1; // 取绝对值
    }
    if(x_now >= 32*1024)   // 如果测量值连续比估计值大或小 相信测量值，加速迭代
    {
        Counter1++;
        Counter2 = 0;
        if(Counter1 > 10)
        {
            R = 512;;
            Q = 128;
        }
    }
    else                 // 数据比较稳定，加强滤波 
    {
        Counter1 = 0;
        Counter2++;
        if(Counter2 > 10)  
        {
            R = (int32_t)(128*1024);
            Q = (int32_t)4;
        }
    }
    x_mid = x_last;   // x_last=x(k-1|k-1),x_mid=x(k|k-1)
    p_mid = p_last + Q; // p_mid=p(k|k-1),p_last=p(k-1|k-1),Q=噪声
//    kg = p_mid/(p_mid + R); //kg为kalman filter，R为噪声
//    x_now = x_mid+kg*(ResrcData - x_mid);// 估计出的最优值
    x_now = x_mid + (p_mid*(ResrcData - x_mid))/(p_mid + R);
//    p_now = (1 - kg)*p_mid; // 最优值对应的covariance
    p_now = p_mid - p_mid*p_mid/(p_mid + R); // 最优值对应的covariance
    p_last = p_now;  // 更新covariance值
    x_last = x_now;  // 更新系统状态值
    x_now /= 1024;
    if((x_now > 4096)||( x_now < 0))
    {
        x_last = ResrcData;
        p_now = ResrcData;
        x_now = ResrcData/1024;
    }
    return (uint32_t)x_now;
}
//累加100次求平均值//
uint16_t get_ave1(float ReadVol_CH4)
{
    static uint8_t  cnt = 0;
    static uint32_t sum = 0;
    static uint16_t ave = 0;
    if( cnt < 150 )
    {
        sum += ReadVol_CH4;           //读取ADC数据
        cnt++;
    }
    if( cnt >= 150 )
    {
        ave = sum / 150;
        cnt = 0;
        sum = 0;
    }
    return ave;
}
uint16_t ADC_Get_VBat(void)
{	
   uint16_t RegularConvData;  // 保存ADC采集后滤波的值 
   uint16_t Bat_Vcc;	      // 保存ADC采集后的值  
   uint16_t i;
	
   if(adc_done != 0x01)
   {
   ADC_StartOfConversion(ADC1);  
   while(ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC) == RESET);  /*检查ADC标志位是否为0*/
   for(i=0; i<2000; i++)
   {
   RegularConvData = ADC_GetConversionValue(ADC1); 
   Bat_Vcc = KalmanFilter(RegularConvData);
   }
   ADC_StopOfConversion(ADC1);
   adc_done = 0x01;
   }
   else
   {
   ADC_StartOfConversion(ADC1);  
   while(ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC) == RESET);  /*检查ADC标志位是否为0*/
   RegularConvData = ADC_GetConversionValue(ADC1); 
   Bat_Vcc = KalmanFilter(RegularConvData);
   ADC_StopOfConversion(ADC1);
   }
   return Bat_Vcc;
}



