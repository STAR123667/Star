/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __LED_H
#define __LED_H

/* Includes ------------------------------------------------------------------*/
#include "stm32f0xx.h"

/* Exported types ------------------------------------------------------------*/
               /* ��Դ�������� */
#define  Power_En_In  GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_4)
               /* ��Դʹ������ */
#define  Power_En_H   GPIO_SetBits(GPIOA, GPIO_Pin_3)     /* ��Դ�ϵ� */
#define  Power_En_L   GPIO_ResetBits(GPIOA, GPIO_Pin_3)   /* ��Դ�ϵ� */ 
              /* ����ָʾ�� */
#define  LED2_OPEN    GPIO_ResetBits(GPIOA, GPIO_Pin_9);	  
#define  LED2_CLOSE   GPIO_SetBits(GPIOA, GPIO_Pin_9);
              /* ����ָʾ�� */
#define  LED3_OPEN    GPIO_ResetBits(GPIOA, GPIO_Pin_10);	
#define  LED3_CLOSE   GPIO_SetBits(GPIOA, GPIO_Pin_10);
              /* ��Դָʾ�� */
#define  Power_Led_Close   GPIO_SetBits(GPIOA, GPIO_Pin_8);	 
#define  Power_Led_Open    GPIO_ResetBits(GPIOA, GPIO_Pin_8);	 

#define LED_LIGHT_L  50
#define LED_LIGHT_H  800

/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */
void Power_En_Init(void);
void Led_Out_Low(void);
void Led_Out_Hight(void);
void Led_Out_Close(void);
void Time6_Init(void);
void Time15_Init(void);
void LED4_Open(void);
void LED4_Close(void);
void PowerUpStart1(uint8_t temp);
void FreePin_Dealwith(void);
void Led_Out_Close2(void);
#endif /* __LED_H */
