#include "main.h"
uint32_t KeyTime;  //����KEY����ʱ��
uint16_t KeyCount; //��¼KEY���´���
uint16_t VBat_Start; //���״̬����
uint16_t TimeCount3s;//ʱ�����
extern bool Led_Flag;      //LED��־//
extern bool Phase_Flag;    //�����־//
extern uint8_t Phase_Start;//����״̬//
extern bool PhaseLine_Flag;
struct Flag
{ 
   uint8_t c:1;
   uint8_t Power_Run:1;
}Key_flag;		
void Get_Phase(void);
int main()
{	
   COMP_Cmd(COMP_Selection_COMP1, DISABLE); 
   COMP_Cmd(COMP_Selection_COMP2, DISABLE);		
   PWR_PVDCmd(DISABLE);	
   PWR_BackupAccessCmd(DISABLE);	
   RTC->CR = RTC->CR & 0xffffff7f;	
   RCC_LSICmd(DISABLE);
   while(RCC_GetFlagStatus(RCC_FLAG_LSIRDY) !=RESET);	
	
   Power_En_Init();       //��Դ���ų�ʼ��
   Buzzer_Init();         //���������ų�ʼ��
   Vbat_Init();           //��ز������ų�ʼ��
   Time14_Init();   	  //��ʱ��14 500USˢ��A B ���ų�ʼ��
   Time17_Init();	      //��ʱ��17 �ο��ź����ų�ʼ��
   Time6_Init();          //��ʱ��6  ��ʱ1MS
   Time3_Init();	      //��ʱ��3  ��ʱ100US 
   Sensor_Init();         //�˷��������ų�ʼ�� 	
	
   VBat_Start = ADC_Get_VBat();	        //��ȡ��ص�ѹ2000�Σ�ʹ������ش����ȶ�״̬��	
   // IWDG_Config(IWDG_Prescaler_64,909);  //���Ź�����3S  	
   
   while(1)
   {   
           // ι��
             // IWDG_Feed();

            if(!Phase_Flag)
			{   
		      Scan_Key();        //��������	  
			}       
	        else 
			{  
		      Get_Phase();	     
			}
	          Get_Battery();     //��ص�ѹ��ȡ,����6V����
   }
}
void Scan_Key(void)
{
	      uint8_t j,i;	
	  	
          if( Power_En_In != Bit_SET)	  
		  {
            Key_flag.c =0;			
		  }   
  
          if( Power_En_In == Bit_SET && Key_flag.c == 0 )	 
	      {		  
            Delay_ms(100);  
	      if( Power_En_In == Bit_SET && Key_flag.c == 0)	  
	      {          
           Key_flag.c =1;
		  }
		  }		  
		  if(Key_flag.c !=0)
		  { 
		   Power_En_H;    /* ��Դ�ϵ� */	
		   Delay_ms(10); 
		   KeyTime++;   
		  }
          
		   if(Key_flag.c !=1)
		  {
//			IWDG_Feed();  		
		   if(KeyTime >1 && KeyTime <=100)  
		  {
			  
		  if(!PhaseLine_Flag)
		  {		
		    KeyCount = KeyCount+1;
		    switch (KeyCount)
            {
          	case 1:
			{ 
			  Power_En_H;    /* ��Դ�ϵ� */	           			  
			 if(Key_flag.Power_Run==0)
			 {		  
			   for(j=0; j<200; j++)
               {
	            TIM_Cmd(TIM15, ENABLE);
                TIM_CtrlPWMOutputs(TIM15, ENABLE);  
                Delay_ms(1);
               }	
                TIM_Cmd(TIM15, DISABLE);
                TIM_CtrlPWMOutputs(TIM15, DISABLE); 
			 
                Key_flag.Power_Run =1;		   
                Led_Flag =1;
                Led_Out_Low();		
			    Delay_ms(1000);
			    Led_Out_Close();
				// IWDG_Feed();  
			     for(i=1;i<=5;i++)
			     {
				   // IWDG_Feed();  
    			   PowerUpStart1(i);   
				   Delay_ms(400); 
                   Get_Battery(); 	
			     }
                  TIM_Cmd(TIM6, ENABLE); 
			  }		     
			  Led_Flag =1;
			  Led_Out_Low();			 
			  KeyTime = 0;	  			         
              TimeCount3s = 0; 		
              // TIM_Cmd(TIM6, ENABLE);   			  
			  TIM_Cmd(TIM14, DISABLE); 			  
			 } 
              break;
          	case 2:
			{ 
			  Power_En_H;    /* ��Դ�ϵ� */	  
			  Led_Out_Hight(); 
			  KeyCount =0; 
			  KeyTime =0;		
			  TimeCount3s =0;
			  // TIM_Cmd(TIM6, ENABLE);   
              TIM_Cmd(TIM14, DISABLE); 
		    }
          		break;
          	default:
          		break;
            }
		 }
			else 
			{ 
			  KeyTime=0; 
			  KeyCount=0;
		      return;
			}
	   }			
		   else if(KeyTime > 100) 
		   {  
	       Led_Out_Close(); 
		   TIM_Cmd(TIM6, DISABLE);  
           TIM_Cmd(TIM14, DISABLE); 		   
		   KeyTime =0;	  
		   KeyCount=0; 
		   Key_flag.Power_Run =0;			  
		   TimeCount3s =0;	
		   Power_En_L;
		   }		   
           else 
           {  
	      			
            if(TIM_GetFlagStatus(TIM6, TIM_FLAG_Update) == SET)  
	        {
			    TIM_ClearFlag(TIM6, TIM_FLAG_Update);
			    TimeCount3s ++; 
                if(TimeCount3s == 1000) 		          //1�����Դָʾ��������������
                { 	
                Led_Out_Close();						
                Power_Led_Open;
				TimeCount3s=0;
                Time3_Init();
                TIM_Cmd(TIM6, DISABLE);  
				TIM_Cmd(TIM14, ENABLE);     //��ʱ��14 ʹ�ܡ�A B���ɨ��	   		   
				Led_Flag=0;  	
				
					
                RCC_HSICmd(ENABLE);
				while(RCC_GetFlagStatus(RCC_FLAG_HSIRDY) !=SET);
                /* Enable Prefetch Buffer and set Flash Latency */
		        FLASH->ACR = FLASH_ACR_PRFTBE | FLASH_ACR_LATENCY;
		        /* HCLK = SYSCLK */
		        RCC->CFGR |= (uint32_t)RCC_CFGR_HPRE_DIV1;
		        /* PCLK = HCLK */
		        RCC->CFGR |= (uint32_t)RCC_CFGR_PPRE_DIV1;
		        // PLL configuration = (HSI/2) * 12 = 48 MHz
		        RCC_PLLConfig(RCC_PLLSource_HSI_Div2, RCC_PLLMul_2); // 8M/2 * 2 = 8M
		        /* Enable PLL */
		        RCC->CR |= RCC_CR_PLLON;
		        /* Wait till PLL is ready */
		        while ((RCC->CR & RCC_CR_PLLRDY) == 0)
		        {
		        }
		        /* Select PLL as system clock source */
		        RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK); // PLL ��ϵͳʱ��
		        /* Wait till PLL is used as system clock source */
		        while ((RCC->CFGR & (uint32_t)RCC_CFGR_SWS) != (uint32_t)RCC_CFGR_SWS_PLL)
		        {
		        }	
			  			
				PWR_EnterSleepMode(PWR_SLEEPEntry_WFI);	   //��������//
						
			    RCC_HSICmd(ENABLE);			
				while(RCC_GetFlagStatus(RCC_FLAG_HSIRDY) !=SET);
				/* Enable Prefetch Buffer and set Flash Latency */
		        FLASH->ACR = FLASH_ACR_PRFTBE | FLASH_ACR_LATENCY;
		        /* HCLK = SYSCLK */
		        RCC->CFGR |= (uint32_t)RCC_CFGR_HPRE_DIV1;
		        /* PCLK = HCLK */
		        RCC->CFGR |= (uint32_t)RCC_CFGR_PPRE_DIV1;
		        // PLL configuration = (HSI/2) * 12 = 48 MHz
		        RCC_PLLConfig(RCC_PLLSource_HSI_Div2, RCC_PLLMul_12); // 8M/2 * 12 = 48M
		        /* Enable PLL */
		        RCC->CR |= RCC_CR_PLLON;
		        /* Wait till PLL is ready */
		        while ((RCC->CR & RCC_CR_PLLRDY) == 0)
		        {
		        }
		        /* Select PLL as system clock source */
		        RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK); // PLL ��ϵͳʱ��
		        /* Wait till PLL is used as system clock source */
		        while ((RCC->CFGR & (uint32_t)RCC_CFGR_SWS) != (uint32_t)RCC_CFGR_SWS_PLL)
		        {
		        }	

	            TIM_Cmd(TIM6, ENABLE);	
				
		        }	  
 			} 	
            else 
		    {   
			    return;
			}		
	
           }   
		   
		}
}
void Get_Battery(void)
{
          VBat_Start = ADC_Get_VBat();    //��ȡ��ص�ѹ   

		  if(VBat_Start<2000)   
         { 
	        Led_Out_Close();
	        for(;1;) 
			{ 
		     // ι��
            // IWDG_Feed();

		     Power_Led_Close;
			 Delay_ms(150);  
           	 Power_Led_Open;
             Delay_ms(150);	 
				
			 VBat_Start = ADC_Get_VBat();
				
             if(VBat_Start>=2000)            //��ص�ѹ��������,6.5V����
			 {
			   break;
			 }
      		}
	      }                            //��1 ��ص�ѹ����7V�������� 
          else 
          {
		    return;
		  }			               //��0 ��ص�ѹ����	
}
void IWDG_Config(uint8_t prv ,uint16_t rlv)
{	
	// ʹ�� Ԥ��Ƶ�Ĵ���PR����װ�ؼĴ���RLR��д
	IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);
	// ����Ԥ��Ƶ��ֵ
	IWDG_SetPrescaler(prv);
	// ������װ�ؼĴ���ֵ
	IWDG_SetReload(rlv);
	// ����װ�ؼĴ�����ֵ�ŵ���������
	IWDG_ReloadCounter();
	// ʹ�� IWDG
	IWDG_Enable();	
}
// ι��
void IWDG_Feed(void)
{
	// ����װ�ؼĴ�����ֵ�ŵ��������У�ι������ֹIWDG��λ
	// ����������ֵ����0��ʱ������ϵͳ��λ
	IWDG_ReloadCounter();
}
void Get_Phase(void)
{
      	    IWDG_Feed();
  		   	if(Phase_Start == 0x01)           /* ���� */		
			{			
					BuzzerOpen_Speen(0x02);   /* �������� */		
			}
			else if(Phase_Start == 0x02)      /* ���� */		
			{
					BuzzerOpen_Speen(0x01);   /* �������� */
			}
			else 
			{
				    BuzzerClose_Speen();      /* �رշ����� */
			}		
}
//static void RTC_Config(void)
//{
//  RTC_InitTypeDef RTC_InitStructure;
//  RTC_TimeTypeDef  RTC_TimeStruct;
//    
//  /* Enable the PWR clock */
//  RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR, ENABLE);
//  
//  /* Allow access to RTC */
//  PWR_BackupAccessCmd(ENABLE);
// 
//  RCC_LSICmd(ENABLE);
//  /* Wait till LSE is ready */  
//  while(RCC_GetFlagStatus(RCC_FLAG_LSIRDY) == RESET)
//  {
//  }
//  /* Select the RTC Clock Source */
//  RCC_RTCCLKConfig(RCC_RTCCLKSource_LSI);
//  
//  RTC_DeInit();
//  
//  /* Configure the RTC data register and RTC prescaler */
//  RTC_InitStructure.RTC_AsynchPrediv = 0x7F;
//  RTC_InitStructure.RTC_SynchPrediv  = 0xFF;
//  RTC_InitStructure.RTC_HourFormat   = RTC_HourFormat_24;
//  RTC_Init(&RTC_InitStructure);
//  
//  /* Set the time to 00h 00mn 00s AM */
//  RTC_TimeStruct.RTC_H12     = RTC_H12_AM;
//  RTC_TimeStruct.RTC_Hours   = 0x00;
//  RTC_TimeStruct.RTC_Minutes = 0x00;
//  RTC_TimeStruct.RTC_Seconds = 0x00;  
//  RTC_SetTime(RTC_Format_BCD, &RTC_TimeStruct);
//  /* Enable the RTC Clock */
//  RCC_RTCCLKCmd(ENABLE);
//  /* Wait for RTC APB registers synchronisation */
//  RTC_WaitForSynchro();
//}
//static void RTC_TamperConfig(void)
//{
//  EXTI_InitTypeDef EXTI_InitStructure;
//  NVIC_InitTypeDef NVIC_InitStructure;
//  
//  /* EXTI configuration *********************************************************/
//  EXTI_ClearITPendingBit(EXTI_Line19);
//  EXTI_InitStructure.EXTI_Line = EXTI_Line19;
//  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
//  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;
//  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
//  EXTI_Init(&EXTI_InitStructure);
//  
//  /* Enable RTC_IRQn */
//  NVIC_InitStructure.NVIC_IRQChannel = RTC_IRQn;
//  NVIC_InitStructure.NVIC_IRQChannelPriority = 0;
//  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//  NVIC_Init(&NVIC_InitStructure);
//  
//  /* determines the number of active pulse for the specific level */
//  RTC_TamperFilterConfig(RTC_TamperFilter_2Sample);
//  
//  /* Determines the frequency at which each of the tamper inputs are sampled */
//  RTC_TamperSamplingFreqConfig(RTC_TamperSamplingFreq_RTCCLK_Div32768);
//  
//  RTC_TamperPullUpCmd(DISABLE);
//  
//  /* Select the tamper 1 with High level */
//  RTC_TamperTriggerConfig(RTC_Tamper_1, RTC_TamperTrigger_LowLevel );
//  
//  /* Clear tamper 1 flag */
//  RTC_ClearFlag(RTC_FLAG_TAMP1F);
//}
//void RTC_IRQHandler(void)
//{
//  if (RTC_GetITStatus(RTC_IT_TAMP1) != RESET)
//  {
//     /* Clear Tamper pin interrupt pending bit */
//     RTC_ClearITPendingBit(RTC_IT_TAMP1);
//  }
//     /* Clear EXTI line 19 */
//     EXTI_ClearITPendingBit(EXTI_Line19);
//}









 

