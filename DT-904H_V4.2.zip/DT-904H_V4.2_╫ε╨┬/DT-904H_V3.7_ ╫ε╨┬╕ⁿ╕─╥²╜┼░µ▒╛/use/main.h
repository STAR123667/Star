/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H
/* Includes ------------------------------------------------------------------*/
#include "stm32f0xx.h"
#include "stdbool.h"
#include "led.h"
#include "delay.h"
#include "vbat.h"
#include "buzzer.h"
#include "sensor.h"
/* Exported types ------------------------------------------------------------*/
//#define uint8_t  u8
//#define uint16_t u16 
//#define uint32_t u32 
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */
void Scan_Key(void);
void Get_Battery(void);
void IWDG_Config(uint8_t prv ,uint16_t rlv);
void IWDG_Feed(void);
#endif /* __MAIN_H */
