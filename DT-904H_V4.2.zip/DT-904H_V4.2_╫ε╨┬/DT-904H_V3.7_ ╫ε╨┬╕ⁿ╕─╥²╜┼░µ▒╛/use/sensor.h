/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __SENSOR_H
#define __SENSOR_H
/* Includes ------------------------------------------------------------------*/
#include "stm32f0xx.h"
/* Exported types ------------------------------------------------------------*/
#define _74VHC4052_A_Hig    GPIO_SetBits(GPIOB, GPIO_Pin_13)
#define _74VHC4052_A_Low    GPIO_ResetBits(GPIOB, GPIO_Pin_13)
#define _74VHC4052_B_Hig    GPIO_SetBits(GPIOB, GPIO_Pin_12)
#define _74VHC4052_B_Low    GPIO_ResetBits(GPIOB, GPIO_Pin_12)
#define _74VHC4052_INH_Hig  GPIO_SetBits(GPIOB, GPIO_Pin_14)
#define _74VHC4052_INH_Low  GPIO_ResetBits(GPIOB, GPIO_Pin_14)

#define _TC7S66FU_CONT_Hig  GPIO_SetBits(GPIOB, GPIO_Pin_15)
#define _TC7S66FU_CONT_Low  GPIO_ResetBits(GPIOB, GPIO_Pin_15)
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */
void Sensor_Init(void);
void Time14_Init(void);
void Time17_Init(void);
void Time3_Init(void);
#endif /* __SENSOR_H */
