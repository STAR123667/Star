/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __VBAT_H
#define __VBAT_H
/* Includes ------------------------------------------------------------------*/
#include "stm32f0xx.h"
/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */
void Vbat_Init(void);
uint32_t KalmanFilter(int32_t ResrcData);
uint16_t get_ave1(float ReadVol_CH4);
uint16_t ADC_Get_VBat(void);
#endif /* __VBAT_H */
