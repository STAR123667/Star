/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __BUZZER_H
#define __BUZZER_H
/* Includes ------------------------------------------------------------------*/
#include "stm32f0xx.h"
/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */
void Buzzer_Init(void);
void BuzzerOpen_Speen(uint8_t Frequency_Select);   // /* 开蜂鸣器 */
void BuzzerClose_Speen(void);     // /* 关闭蜂鸣器 */
#endif /* __BUZZER_H */
