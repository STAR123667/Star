#include "delay.h"
//#include "systick.h"
// extern uint32_t systime;
// /* ��ʱ���� 10us */
// void delay_10us(void)
// {
      // unsigned int temp;
      // temp = systime;
      // while((systime - temp) < 1);
// }
// /* ��ʱ���� 100us */
// void delay_100us(void)
// {
      // unsigned int temp;
      // temp = systime;
      // while((systime - temp) < 10);
// }

// /* ��ʱ���� 600us */
// void delay_600us(void)
// {
      // unsigned int temp;
      // temp = systime;
      // while((systime - temp) < 60);
// }

// /* ��ʱ���� 1ms */
// void delay_1ms(void)
// {
  // unsigned int temp;
  // temp = systime;
  // while((systime - temp) < 100);
// }
// void delay_10ms(void)
// {
  // unsigned int temp;
  // temp = systime;
  // while((systime - temp) < 1000);
// }
// void delay_50ms(void)
// {
  // unsigned int temp;
  // temp = systime;
  // while((systime - temp) < 5000);
// }
// /* ��ʱ���� 100ms */
// void delay_100ms(void)
// {
  // unsigned int temp;
  // temp = systime;
  // while((systime - temp) < 10000);
// }
// /* ��ʱ���� 100ms */
// void delay_150ms(void)
// {
  // unsigned int temp;
  // temp = systime;
  // while((systime - temp) < 15000);
// }
// /* ��ʱ���� 200ms */
// void delay_200ms(void)
// {
  // unsigned int temp;
  // temp = systime;
  // while((systime - temp) < 20000);
// }
// /* ��ʱ���� 300ms */
// void delay_300ms(void)
// {
  // unsigned int temp;
  // temp = systime;
  // while((systime - temp) < 30000);
// }
// /* ��ʱ���� 400ms */
// void delay_400ms(void)
// {
  // unsigned int temp;
  // temp = systime;
  // while((systime - temp) < 40000);
// }

// /* ��ʱ���� 500ms */
// void delay_500ms(void)
// {
  // unsigned int temp;
  // temp = systime;
  // while((systime - temp) < 50000);
// }
// /* ��ʱ���� 1s */
// void delay_1s(void)
// {
  // unsigned int temp;
  // temp = systime;
  // while((systime - temp) < 100000);
// }

/**********  ������ͨ��ʱ  **********/

/* ��ʱ���� 10us */
void Delay_10us(uint32_t time)
{
  uint32_t i=68*time;
  while(i--);
} 
/* ��ʱ���� 1ms */
void Delay_ms(uint32_t time)
{
  uint32_t i=6850*time;
  while(i--);
}




