#include "buzzer.h"
#include "delay.h"
void Buzzer_Init(void)
{
  TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
  TIM_OCInitTypeDef  TIM_OCInitStructure;
  GPIO_InitTypeDef GPIO_InitStructure;  
  
  /* GPIOA Clocks enable */  
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE); 
  /* TIM15 clock enable */ 
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM15, ENABLE);
  
  GPIO_PinAFConfig(GPIOA, GPIO_PinSource2, GPIO_AF_0);
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_DOWN;
  GPIO_Init(GPIOA, &GPIO_InitStructure);	
	
    // /* Time Base configuration */
  TIM_TimeBaseStructure.TIM_Prescaler = 48;
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
  TIM_TimeBaseStructure.TIM_Period = 500-1;
  TIM_TimeBaseStructure.TIM_ClockDivision = 1;
  TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
  TIM_TimeBaseInit(TIM15, &TIM_TimeBaseStructure);
 
  /* Channel 1, 2,3 and 4 Configuration in PWM mode */
  TIM_OCStructInit(&TIM_OCInitStructure);
  TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2;
  TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
  TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Enable;
  TIM_OCInitStructure.TIM_OCNPolarity = TIM_OCNPolarity_Low;
  TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Set;
  TIM_OCInitStructure.TIM_OCNIdleState = TIM_OCIdleState_Reset;
  TIM_OCInitStructure.TIM_Pulse = 250;
  TIM_OC1Init(TIM15, &TIM_OCInitStructure);
   // /* TIM15 counter enable */
  TIM_Cmd(TIM15, DISABLE);
    // /* TIM15 Main Output Enable */
  TIM_CtrlPWMOutputs(TIM15, DISABLE);
} 
void BuzzerOpen_Speen(uint8_t Frequency_Select)   // /* 开蜂鸣器 */
{
        uint16_t BuzTime; 
		 		 
	    if(Frequency_Select==0x01)
        {
		  BuzTime=250;  	
	    }
        else if(Frequency_Select==0x02)
        {
		  BuzTime=500;  	
	    }
	    else 
		{ 
	      return;
		}
		  TIM_Cmd(TIM15, ENABLE);
          TIM_CtrlPWMOutputs(TIM15, ENABLE);  
          Delay_ms(BuzTime);	 
		  TIM_Cmd(TIM15, DISABLE);
          TIM_CtrlPWMOutputs(TIM15, DISABLE); 	
	      Delay_ms(BuzTime);		
}
void BuzzerClose_Speen(void)     // /* 关闭蜂鸣器 */
{
   TIM_Cmd(TIM15, DISABLE);
   TIM_CtrlPWMOutputs(TIM15, DISABLE); 	
}

 
 
 


