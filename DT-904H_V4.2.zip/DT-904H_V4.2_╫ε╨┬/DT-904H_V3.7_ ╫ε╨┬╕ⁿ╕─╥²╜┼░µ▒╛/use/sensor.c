#include "sensor.h"
void Sensor_Init(void)
{
  GPIO_InitTypeDef   GPIO_InitStructure; 
  EXTI_InitTypeDef   EXTI_InitStructure;
  NVIC_InitTypeDef   NVIC_InitStructure;

  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE); 		
  /* Enable SYSCFG clock */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);
	
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;  
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_Init(GPIOB, &GPIO_InitStructure);	
  
   /* Configure PB9 PB0 pin as input floating */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9 | GPIO_Pin_0;  //PB0����
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
  GPIO_Init(GPIOB, &GPIO_InitStructure);
  
  /* Connect EXTI1 Line to PB9 pin */
  SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOB, EXTI_PinSource9);	
	
    /* Configure EXTI9 line */
  EXTI_InitStructure.EXTI_Line = EXTI_Line9;
  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;   //�ⲿλ�������ж�
  EXTI_InitStructure.EXTI_LineCmd = ENABLE;           
  EXTI_Init(&EXTI_InitStructure);	

   /* Enable and set EXTI0_1 Interrupt */
  NVIC_InitStructure.NVIC_IRQChannel = EXTI4_15_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPriority = 2;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
  
   _74VHC4052_A_Low;      // ����74VHC4052 X3-Y3��ͨ 
   _74VHC4052_B_Low;   
   _74VHC4052_INH_Low;    // ����74VHC4052 INH�� 
   
   _TC7S66FU_CONT_Hig;    // ����TC7S66FUʹ�� 
}
//���ö�ʱ��14,��ʱˢ��74VHC4052�� A��B�˿�//
void Time14_Init(void)
{
  TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
  NVIC_InitTypeDef  NVIC_InitStructure;
	
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM14, ENABLE);
   /* Time base configuration */
  TIM_TimeBaseStructure.TIM_Period = 500-1;    //��ʱ������ֵ�趨
  TIM_TimeBaseStructure.TIM_Prescaler = 48;  //��ʱ��Ԥ����ֵ�趨
  TIM_TimeBaseStructure.TIM_ClockDivision = 1;   // ʱ�ӷ�Ƶֵ�趨
  TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
  TIM_TimeBaseInit(TIM14, &TIM_TimeBaseStructure);

  	/* Enable the TIM14 gloabal Interrupt */
  NVIC_InitStructure.NVIC_IRQChannel = TIM14_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
  /* Prescaler configuration */
  TIM_ClearFlag(TIM14, TIM_FLAG_Update);                              //?????,??????????????
  TIM_ARRPreloadConfig(TIM14, ENABLE);                               //??ARR?????? 
  TIM_ITConfig(TIM14,TIM_IT_Update, ENABLE);                       //??TIM3????
  TIM_Cmd(TIM14, DISABLE);                                                       //??TIM3 ???
}
void Time3_Init(void)
{
  TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
  NVIC_InitTypeDef  NVIC_InitStructure;
 
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE); 
   /* Time base configuration */
  TIM_TimeBaseStructure.TIM_Period = 100-1;    //��ʱ������ֵ�趨
  TIM_TimeBaseStructure.TIM_Prescaler = 48;  //��ʱ��Ԥ����ֵ�趨
  TIM_TimeBaseStructure.TIM_ClockDivision = 1;   // ʱ�ӷ�Ƶֵ�趨
  TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
  TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);
  	/* Enable the TIM3 gloabal Interrupt */
  NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPriority = 3;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);

  /* Prescaler configuration */
  TIM_ClearFlag(TIM3, TIM_FLAG_Update);                              //?????,??????????????
  TIM_ARRPreloadConfig(TIM3, ENABLE);                               //??ARR?????? 
  TIM_ITConfig(TIM3,TIM_IT_Update, ENABLE);                       //??TIM3????
  TIM_Cmd(TIM3, DISABLE);                                                       //??TIM3 ???
}	
void Time17_Init(void)
{ 
    GPIO_InitTypeDef   GPIO_InitStructure;
	EXTI_InitTypeDef   EXTI_InitStructure;
	NVIC_InitTypeDef   NVIC_InitStructure;

	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    TIM_OCInitTypeDef  TIM_OCInitStructure;
	
    /* Configure PB1 pin as input floating */
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOA, &GPIO_InitStructure); 
    // /* Connect EXTI1 Line to PB1 pin */
    SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOA, EXTI_PinSource6);		
    // /* Configure EXTI11 line */
    EXTI_InitStructure.EXTI_Line = EXTI_Line6;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising;   //�ⲿλ�������ж�
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;           
    EXTI_Init(&EXTI_InitStructure);
    // /* Enable and set EXTI0_1 Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = EXTI4_15_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
 
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE); 
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM17, ENABLE); 
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource7, GPIO_AF_5);
	
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_PuPd =  GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOA, &GPIO_InitStructure);	
    /* Time base configuration */
    TIM_TimeBaseStructure.TIM_Period = 20000-1;    //��ʱ������ֵ�趨
    TIM_TimeBaseStructure.TIM_Prescaler = 48;  //��ʱ��Ԥ����ֵ�趨
    TIM_TimeBaseStructure.TIM_ClockDivision = 1;   // ʱ�ӷ�Ƶֵ�趨
    TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM17, &TIM_TimeBaseStructure);
      // /* Channel 1, 2,3 and 4 Configuration in PWM mode */
    TIM_OCStructInit(&TIM_OCInitStructure);
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_OutputNState = TIM_OutputNState_Enable;
    TIM_OCInitStructure.TIM_OCNPolarity = TIM_OCNPolarity_High;
    TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Reset;//����ȽϿ���״̬
    TIM_OCInitStructure.TIM_OCNIdleState = TIM_OCNIdleState_Reset;//����ȽϿ���״̬
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; //����Ƚϼ���
    TIM_OCInitStructure.TIM_Pulse = 10000;
    TIM_OC1Init(TIM17, &TIM_OCInitStructure);
     // /* TIM1 counter enable */
    TIM_Cmd(TIM17, DISABLE);
    // /* TIM1 Main Output Enable */
    TIM_CtrlPWMOutputs(TIM17, DISABLE);
}
